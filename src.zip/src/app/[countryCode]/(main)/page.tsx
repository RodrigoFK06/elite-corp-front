import { Metadata } from "next"

import Hero from "@modules/home/components/hero"
import ProductRail from "@modules/home/components/featured-products/product-rail"
import { listCollections } from "@lib/data/collections"
import { getRegion } from "@lib/data/regions"

export const metadata: Metadata = {
  title: "Perfumes Élite | Fragancias de lujo accesibles",
  description:
    "Perfumes inspirados en las mejores marcas, con alta duración y precios accesibles. Perfumes Élite, lujo para todos.",
}

export default async function Home(props: {
  params: Promise<{ countryCode: string }>
}) {
  const { countryCode } = await props.params

  const region = await getRegion(countryCode)

  const { collections } = await listCollections({
    fields: "id,handle,title",
  })

  if (!collections || !region) return null

  const destacados = collections.find((c) => c.title === "Productos Destacados")
  const perfume = collections.find((c) => c.title === "Perfume")
  const perfumesHombre = collections.find((c) => c.title === "Perfumes Hombre")
  const perfumesMujer = collections.find((c) => c.title === "Perfumes Mujer")

  return (
    <div className="bg-[#FFF9EF]"> {/* Fondo uniforme pastel */}
      <Hero />

      {/* Sección: Productos Destacados */}
      {destacados && (
        <section className="py-5">
          <h2 className="text-3xl font-bold text-center text-dorado mb-8 uppercase">
            Productos Destacados
          </h2>
          <ProductRail collection={destacados} region={region} />
        </section>
      )}

      {/* Sección: Perfumes */}
      {perfume && (
        <section className="py-5">
          <h2 className="text-3xl font-bold text-center text-dorado mb-8 uppercase">
            Perfumes
          </h2>
          <ProductRail collection={perfume} region={region} />
        </section>
      )}

      {/* Sección: Perfumes Hombre */}
      {perfumesHombre && (
        <section className="py-5">
          <h2 className="text-3xl font-bold text-center text-dorado mb-8 uppercase">
            Perfumes Hombre
          </h2>
          <ProductRail collection={perfumesHombre} region={region} />
        </section>
      )}

      {/* Sección: Perfumes Mujer */}
      {perfumesMujer && (
        <section className="py-5">
          <h2 className="text-3xl font-bold text-center text-dorado mb-8 uppercase">
            Perfumes Mujer
          </h2>
          <ProductRail collection={perfumesMujer} region={region} />
        </section>
      )}
    </div>
  )
}

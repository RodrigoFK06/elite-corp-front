import { listProducts } from "@lib/data/products"
import { HttpTypes } from "@medusajs/types"
import InteractiveLink from "@modules/common/components/interactive-link"
import ProductPreview from "@modules/products/components/product-preview"

export default async function ProductRail({
  collection,
  region,
}: {
  collection: HttpTypes.StoreCollection
  region: HttpTypes.StoreRegion
}) {
  const {
    response: { products: allProducts },
  } = await listProducts({
    regionId: region.id,
    queryParams: {
      fields:
        "id,title,handle,thumbnail,images,collection.id,collection.title,variants.calculated_price",
      limit: 100,
    },
  })

  const filteredProducts = allProducts.filter(
    (p) => p.collection?.id === collection.id
  )

  if (!filteredProducts || filteredProducts.length === 0) return null

  console.log("🔎 Productos totales:", allProducts.length)
  console.log("✅ En la colección:", filteredProducts.map(p => p.title))

  return (
    <section className="w-full bg-[#FFF9EF] py-6">
      <div className="content-container">
        {/* Link a la colección alineado a la derecha */}
        <div className="flex justify-end mb-4">
          <InteractiveLink href={`/collections/${collection.handle}`}>
            Ver todo
          </InteractiveLink>
        </div>

        <ul className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-12">
          {filteredProducts.map((product) => (
            <li
              key={product.id}
              className="bg-white rounded-md shadow-sm border border-gray-200 p-2 hover:shadow-lg transition-transform transform hover:-translate-y-1 duration-200"
            >
              <ProductPreview product={product} region={region} isFeatured />
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}

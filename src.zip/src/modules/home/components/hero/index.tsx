import Image from "next/image"

const Hero = () => {
  return (
    <section className="bg-pastel-base px-6 py-16 flex flex-col lg:flex-row items-center justify-center gap-12">
      {/* LADO IZQUIERDO - TEXTO */}
      <div className="text-center lg:text-left max-w-xl">
        <span className="inline-block bg-yellow-200 text-cafe font-bold px-4 py-2 rounded-full text-sm mb-4">
          NUEVO LANZAMIENTO
        </span>

        <h1 className="text-4xl lg:text-5xl font-serif font-bold text-cafe mb-4 leading-tight">
          Fragancias de lujo al <br /> alcance de todos
        </h1>

        <p className="text-md text-texto mb-6">
          Descubre nuestra exclusiva colección de perfumes que combinan elegancia,
          distinción y calidad excepcional.
        </p>

        <a
          href="/collections"
          className="bg-dorado hover:bg-yellow-500 transition text-black font-bold py-3 px-6 rounded-md inline-block"
        >
          COMPRAR AHORA
        </a>
      </div>

      {/* LADO DERECHO - IMAGEN */}
      <div className="w-[320px] lg:w-[400px] rounded-xl shadow-lg overflow-hidden">
        <Image
          src="/img/productos-hero.jpg"
          alt="Productos destacados"
          width={400}
          height={400}
          className="rounded-xl shadow-lg"
        />
      </div>
    </section>
  )
}

export default Hero
